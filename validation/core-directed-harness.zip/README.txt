HY-RV canonical directed harness (unchanged verified source)

Extract this archive into a new directory, then run:
python3 tests/run_frontend_tests.py --mode all --preset ant_j0 --rtl-source /absolute/path/to/rv-lab/rtl

Repeat with ant_j1, btfnt_j0, btfnt_j1. Requires Verilator and a modern C++ compiler. Set CCACHE_DIR to a writable directory. Only mode all is packaged; historical equivalence mode needs additional upstream baseline inputs.
The software lab tests and their signatures are covered separately by functional-p1.json.
