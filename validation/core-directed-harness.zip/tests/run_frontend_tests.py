#!/usr/bin/env python3
# =============================================================================
# HY-RV | run_frontend_tests
# Description: Build and run isolated frontend, predictor, and backend directed tests.
#
# Purpose: Computer architecture and RTL design education and lab exercises.
# Maintained by: DSAL (Digital System Architecture Lab), Hanyang University
# Website: https://dsa.hanyang.ac.kr
# Supervisor: Prof. Ji-Hoon Kim (jhoonkim@hanyang.ac.kr)
#
# AI tools such as Codex or Claude may have assisted in creating or modifying
# this file. See the applicable manifests and verification records for
# file-specific provenance, revision history, and validation evidence.
# Preserve existing license, copyright, and original author notices.
# =============================================================================

"""Isolated stage checks for this model's frontend, static BP and P correction."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

MODEL = Path(__file__).resolve().parents[1]
REPO = MODEL.parents[1]
FROZEN = REPO / "core/build/harness/rtl/teaching_fetch.sv"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command: list[str], log: Path, timeout: int = 600) -> str:
    result = subprocess.run(command, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=timeout)
    log.write_text(result.stdout)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {log}\n{result.stdout[-5000:]}")
    return result.stdout


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rtl-source", type=Path, default=MODEL / "rtl")
    parser.add_argument("--stage", default="C0_modularize")
    parser.add_argument("--preset", choices=("ant_j0", "ant_j1", "btfnt_j0", "btfnt_j1"), default="ant_j0")
    parser.add_argument("--mode", choices=("equivalence", "transport", "static", "all"), default="equivalence")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--require-ii1", type=int, choices=(0, 1), default=1)
    args = parser.parse_args()
    rtl = args.rtl_source.resolve()
    args.output = (args.output or MODEL / "build" / args.stage / args.preset / "frontend-tests/report.json").resolve()
    build = args.output.parent
    build.mkdir(parents=True, exist_ok=True)
    config = json.loads((MODEL / "handoff/profile.json").read_text())["presets"][args.preset]
    config_bytes = json.dumps(config, sort_keys=True, separators=(",", ":")).encode()
    verilator = shutil.which(os.environ.get("VERILATOR", "verilator"))
    preferred_cxx = "/opt/rh/gcc-toolset-12/root/usr/bin/g++"
    cxx = shutil.which(os.environ.get("CXX", preferred_cxx if Path(preferred_cxx).exists() else "g++"))
    report = {"status": "fail", "stage": args.stage, "mode": args.mode, "preset": args.preset, "model_id": config["model_id"],
              "configuration": config, "config_sha256": hashlib.sha256(config_bytes).hexdigest(),
              "rtl_source": str(rtl), "runner_sha256": digest(Path(__file__)), "tests": []}
    try:
        if not verilator or not cxx:
            raise RuntimeError("Verilator and a C++ compiler are required")
        tool_identity = {"verilator": subprocess.check_output([verilator, "--version"], text=True).strip(),
                         "verilator_path": verilator, "cxx_path": cxx,
                         "verilator_launcher_sha256": digest(Path(verilator)), "cxx_binary_sha256": digest(Path(cxx)),
                         "cxx": subprocess.check_output([cxx, "--version"], text=True).splitlines()[0]}
        verilator_binary = Path(verilator).resolve().parent / "verilator_bin"
        if verilator_binary.exists():
            tool_identity["verilator_binary_sha256"] = digest(verilator_binary)
        sources = [rtl / line.strip() for line in (rtl / "filelist.f").read_text().splitlines()
                   if line.strip() and not line.lstrip().startswith("#")]
        tests: list[tuple[str, list[Path], list[str]]] = []
        if args.mode == "equivalence":
            baseline_manifest = REPO / "core/SOURCE_BASELINE.json"
            expected = json.loads(baseline_manifest.read_text())["sha256"]["teaching_fetch.sv"]
            if digest(FROZEN) != expected:
                raise RuntimeError("Frozen teaching_fetch differs from SOURCE_BASELINE.json")
            report["baseline_fetch_sha256"] = expected
            tests += [("gen_pc_nxt_tb", [rtl / "frontend/gen_pc_nxt.sv", REPO / "core/tests/gen_pc_nxt_tb.sv"], []),
                      ("frontend_equivalence_tb", [*sources, FROZEN, (MODEL if (rtl / "common/rv_bp_pkg.sv").exists() else REPO / "core") / "tests/frontend_equivalence_tb.sv"], ["+define+EXPLICIT_FRONTEND_CONTROL"]),
                      ("insn_link_tb", [*([rtl / "common/rv_bp_pkg.sv"] if (rtl / "common/rv_bp_pkg.sv").exists() else []), rtl / "common/insn_supply_if.sv", rtl / "common/rv_insn_link.sv", REPO / "core/tests/insn_link_tb.sv"], [])]
        else:
            parameters = [f"-GCOND_POLICY={int(config['COND_POLICY'] == 'BTFNT')}",
                          f"-GEARLY_JAL_EN={config['EARLY_JAL_EN']}"]
            if args.mode in ("transport", "all"):
                tests.append(("frontend_transport_tb", [*sources, MODEL / "tests/frontend_transport_tb.sv"], [*parameters, f"-GREQUIRE_II1={args.require_ii1}"]))
            if args.mode in ("static", "all"):
                tests.append(("static_prediction_tb", [*sources, MODEL / "tests/static_prediction_tb.sv"], parameters))
                if (MODEL / "tests/backend_successor_tb.sv").exists():
                    tests.append(("backend_successor_tb", [*sources, MODEL / "tests/backend_successor_tb.sv"], []))
        for top, test_sources, extras in tests:
            # Verilator 5.028 can terminate before time advances when a large
            # initial coroutine is split into generated child coroutines.
            flags = ["--binary", "--timing", "--assert", "-Wno-fatal", "--output-split", "0", "--output-split-cfuncs", "0", "--top-module", top, *extras]
            identity = {**tool_identity, "flags": flags, "configuration": config,
                        "config_sha256": report["config_sha256"],
                        "sources": {str(p): digest(p) for p in test_sources}}
            if top == "static_prediction_tb":
                identity["compiled_controls"] = {"BP_PROFILE": int(config["COND_POLICY"] == "BTFNT"), "COND_POLICY": int(config["COND_POLICY"] == "BTFNT"), "EARLY_JAL_EN": config["EARLY_JAL_EN"], "STATIC_POLICY_EN": 1, "SUCCESSOR_CHECK_EN": 1, "memory_adapter": "independent L1/II1 stable response hold"}
            elif top == "frontend_transport_tb":
                identity["compiled_controls"] = {"BP_PROFILE": int(config["COND_POLICY"] == "BTFNT"), "COND_POLICY": int(config["COND_POLICY"] == "BTFNT"), "EARLY_JAL_EN": config["EARLY_JAL_EN"], "STATIC_POLICY_EN": 1, "REQUIRE_II1": args.require_ii1, "memory_adapter": "independent variable latency 1..7, same-edge reuse, stable hold"}
            elif top == "backend_successor_tb":
                identity["compiled_controls"] = {"SUCCESSOR_CHECK_EN": 1, "memory_adapter": "direct token and owned D-memory response injection"}
            portable_sources = {}
            for source in test_sources:
                try:
                    label = "rtl/" + str(source.relative_to(rtl))
                except ValueError:
                    try:
                        label = str(source.relative_to(MODEL))
                    except ValueError:
                        label = "reference/" + str(source.relative_to(REPO))
                portable_sources[label] = digest(source)
            identity["source_sha256"] = hashlib.sha256(json.dumps(portable_sources, sort_keys=True).encode()).hexdigest()
            identity["compiled_config_sha256"] = hashlib.sha256(json.dumps({"configuration": config, "compiled_controls": identity.get("compiled_controls", {}), "flags": flags}, sort_keys=True).encode()).hexdigest()
            key = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()[:16]
            destination = build / top / key
            destination.mkdir(parents=True, exist_ok=True)
            binary = destination / ("V" + top)
            command = [verilator, *flags, "--Mdir", str(destination), "-j", "4", "-MAKEFLAGS", f"CXX={cxx}", *map(str, test_sources)]
            if not binary.exists():
                run(command, destination / "build.log")
            run_command = [str(binary)]
            if top == "static_prediction_tb":
                run_command.append(f"+trace_file={destination / 'overlap.csv'}")
            elif top == "frontend_transport_tb":
                run_command.append(f"+transport_trace_dir={destination}")
            output = run(run_command, destination / "run.log", timeout=120)
            if {str(p): digest(p) for p in test_sources} != identity["sources"]:
                raise RuntimeError(f"Sources changed during {top}; rerun on a stable snapshot")
            if "PASS " not in output and "BACKEND_SUCCESSOR_PASS checks=" not in output:
                raise RuntimeError(f"No completion evidence in {destination / 'run.log'}")
            report["tests"].append({"name": top, "status": "pass", "identity": identity,
                                    "build_key": key, "build_command": command, "run_command": run_command, "binary_sha256": digest(binary),
                                    "source_hashes_stable": True, "log": str(destination / "run.log"), "output": output.strip()})
            print(output.strip(), flush=True)
        report["status"] = "pass"
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as exc:
        report["error"] = str(exc)
        print(str(exc), file=sys.stderr)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(f"Frontend checks: {report['status'].upper()} — {args.output}")
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
