// =============================================================================
// HY-RV | frontend_transport_tb
// Description: Directed checks of fetch ownership, response holds, recovery, and II=1.
//
// Purpose: Computer architecture and RTL design education and lab exercises.
// Maintained by: DSAL (Digital System Architecture Lab), Hanyang University
// Website: https://dsa.hanyang.ac.kr
// Supervisor: Prof. Ji-Hoon Kim (jhoonkim@hanyang.ac.kr)
//
// AI tools such as Codex or Claude may have assisted in creating or modifying
// this file. See the applicable manifests and verification records for
// file-specific provenance, revision history, and validation evidence.
// Preserve existing license, copyright, and original author notices.
// =============================================================================

// Independent single-owner memory producer, with same-edge completion/reuse.
// Random responses obey minimum L=1 and stable payload; no response buffer exists.
module frontend_transport_engine #(
    parameter logic [31:0] RESET_PC=32'h8000_0000,
    parameter int unsigned COND_POLICY=0,
    parameter bit EARLY_JAL_EN=0, REQUIRE_II1=1,
    parameter logic[31:0] SEED=32'hd3846a21
)(output logic done=0);
    import rv_bp_pkg::*;
    logic clk=0,rst_n=0,drain=0,redirect=0,consumer_ready=0;
    logic [31:0] redirect_pc=0,resume_pc=RESET_PC;
    logic idle,lookup_valid,refine_valid,frontend_kill;
    logic[31:0]lookup_pc,refine_pc;
    bp_lookup_t lookup,saved_lookup;
    bp_predecode_t predecode;
    bp_prediction_t effective;
    mem_if memory();
    insn_supply_if f_if(),p_if();
    rv_frontend #(.RESET_PC(RESET_PC)) frontend(
        .clk,.rst_n,.drain_req_i(drain),.redirect_i(redirect),.redirect_pc_i(redirect_pc),.resume_pc_i(resume_pc),.backend_idle_i(1'b1),.idle_o(idle),.kill_o(frontend_kill),
        .lookup_valid_o(lookup_valid),.lookup_pc_o(lookup_pc),.lookup_record_i(lookup),.refine_valid_o(refine_valid),.refine_pc_o(refine_pc),.predecode_o(predecode),.saved_lookup_o(saved_lookup),.effective_i(effective),
        .imem_if(memory),.insn_if(f_if));
    rv_branch_predictor #(.BP_PROFILE(COND_POLICY),.COND_POLICY(COND_POLICY),.EARLY_JAL_EN(EARLY_JAL_EN),.STATIC_POLICY_EN(1)) predictor(
        .clk,.rst_n,.lookup_valid_i(lookup_valid),.lookup_pc_i(lookup_pc),.lookup_record_o(lookup),.refine_valid_i(refine_valid),.refine_pc_i(refine_pc),.predecode_i(predecode),.saved_lookup_i(saved_lookup),.effective_o(effective),
        .update_valid_i(1'b0),.update_i('0),.invalidate_frontend_state_i(1'b0));
    rv_insn_link link(.rst_n,.flush_i(frontend_kill),.f_if,.p_if);
    assign p_if.ready=consumer_ready;

    bit model_live=0,model_error=0,model_stale=0,offer_stale=0;
    int model_delay=0,service_latency=1;
    bit service_error=0;
    logic[31:0]model_pc=0,rng=SEED;
    int cycles=0,requests=0,tokens=0,stalled_requests=0,stalled_tokens=0;
    int held_redirects=0,pending_redirects=0,response_redirects=0,stale_faults=0,drain_responses=0,local_faults=0,fresh_faults=0,same_edge_reuse=0;
    bit previous_held=0,previous_token_stalled=0,previous_kill=0,fault_barrier=0;
    bit restart_check=0;
    logic[31:0]restart_target;
    int restart_checks=0;
    int trace_fd=0;
    string trace_dir;
    logic[31:0]previous_address;
    logic[$bits(bp_prediction_t)+$bits(bp_lookup_t)+66-1:0] previous_token;

    function automatic logic[31:0]random_word();
        rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);return rng;
    endfunction
    function automatic logic[31:0]memory_word(input logic[31:0]pc);
        return {pc[15:0],16'h0013}; // legal ADDI-shaped or ordinary non-CFI bytes
    endfunction
    task automatic check_outputs;
        bit kill;
        kill=frontend_kill;
        if(previous_held)assert(memory.req_valid&&memory.req_addr==previous_address) else $fatal(1,"Held offer withdrawn across control at cycle %0d",cycles);
        if(previous_token_stalled&&!kill)assert(p_if.valid&&{p_if.pc,p_if.insn,p_if.fault,p_if.fault_misaligned,p_if.prediction,p_if.bp_meta}==previous_token) else $fatal(1,"Stalled full token changed at cycle %0d",cycles);
        if(kill)assert(!p_if.valid&&!f_if.valid) else $fatal(1,"Control admitted younger token");
        if(p_if.valid)begin
            if(p_if.fault_misaligned)begin
                assert(p_if.fault&&p_if.pc[1:0]!=0&&p_if.insn==32'h13&&p_if.bp_meta=='0) else $fatal(1,"Malformed local fault");
            end else begin
                assert(model_live&&!model_stale&&!kill&&p_if.pc==model_pc) else $fatal(1,"Token association lost pc=%h owner=%h live=%b stale=%b",p_if.pc,model_pc,model_live,model_stale);
                assert(p_if.fault==model_error&&p_if.insn==(model_error?32'h13:memory_word(model_pc))) else $fatal(1,"Token bytes/status lost");
            end
            assert(p_if.prediction.next_pc==p_if.pc+4&&!p_if.prediction.taken&&p_if.prediction.source==BP_SEQ) else $fatal(1,"Fault/non-CFI prediction malformed");
            if(restart_check&&p_if.fault_misaligned)assert(p_if.pc==restart_target) else $fatal(1,"Wrong latest local restart target");
        end
        if(fault_barrier&&!kill)assert(!memory.req_valid||previous_held) else $fatal(1,"Fault barrier issued younger memory request");
        if(model_live&&!model_stale&&!kill&&memory.resp_valid&&memory.resp_error)assert(!memory.req_valid) else $fatal(1,"First visible fault issued younger request");
        if(memory.req_valid)assert(memory.req_addr[1:0]==0&&memory.req_id==0&&!memory.req_write) else $fatal(1,"Malformed instruction request");
    endtask
    task automatic tick(input bit allow_request,input bit allow_token,input bit stop,input bit do_redirect,input logic[31:0]target);
        bit accepted,consumed,token_fire,kill;
        logic[31:0]accepted_pc;
        memory.resp_valid=model_live&&model_delay==0;
        memory.resp_id=0;
        if(model_live)begin memory.resp_error=model_error;memory.resp_rdata=model_error?0:memory_word(model_pc);end
        consumer_ready=allow_token;drain=stop;redirect=do_redirect;redirect_pc=target;
        memory.req_ready=0;#1;
        memory.req_ready=allow_request&&(!model_live||(memory.resp_valid&&memory.resp_ready));#1;
        check_outputs();
        accepted=memory.req_valid&&memory.req_ready;consumed=memory.resp_valid&&memory.resp_ready;token_fire=p_if.valid&&p_if.ready;accepted_pc=memory.req_addr;kill=frontend_kill;
        if(trace_fd!=0)$fwrite(trace_fd,"%0d,%0d,%08h,%0d,%08h,%0d,%08h,%0d,%0d,%0d,%0d,%0d,%0d,%0d\n",cycles,accepted,memory.req_addr,consumed,model_pc,token_fire,p_if.pc,memory.resp_error,model_stale,p_if.fault,p_if.fault_misaligned,do_redirect,stop,kill);
        if(kill&&!do_redirect)restart_check=0;
        if(do_redirect)begin restart_check=1;restart_target=target;end
        if(memory.req_valid&&!memory.req_ready)stalled_requests++;
        if(p_if.valid&&!p_if.ready)stalled_tokens++;
        if(token_fire)begin
            tokens++;resume_pc=p_if.pc+4;
            if(p_if.fault_misaligned)local_faults++;
            else if(p_if.fault)fresh_faults++;
        end
        if(do_redirect&&previous_held)held_redirects++;
        if(do_redirect&&model_live)pending_redirects++;
        if(do_redirect&&consumed)response_redirects++;
        if(kill&&memory.req_valid)offer_stale=1;
        if(kill&&model_live)model_stale=1;
        if(consumed&&model_stale&&model_error)stale_faults++;
        if(consumed&&stop)drain_responses++;
        if(accepted&&consumed)same_edge_reuse++;
        if(accepted&&!kill&&!offer_stale&&restart_check)begin
            assert(accepted_pc==restart_target) else $fatal(1,"Stale drain lost latest redirect target expected=%h got=%h",restart_target,accepted_pc);
            restart_checks++;restart_check=0;
        end
        if(token_fire&&p_if.fault_misaligned&&restart_check)begin restart_checks++;restart_check=0;end
        if(kill)fault_barrier=0;
        else if(p_if.valid&&p_if.fault)fault_barrier=1;
        previous_held=memory.req_valid&&!memory.req_ready;previous_address=memory.req_addr;
        previous_token_stalled=p_if.valid&&!p_if.ready;previous_token={p_if.pc,p_if.insn,p_if.fault,p_if.fault_misaligned,p_if.prediction,p_if.bp_meta};previous_kill=kill;
        clk=1;#1;
        if(consumed)begin model_live=0;model_stale=0;end
        else if(model_live&&model_delay>0)model_delay--;
        if(accepted)begin
            assert(!model_live) else $fatal(1,"Memory producer overcommit");
            model_live=1;model_pc=accepted_pc;model_delay=service_latency-1;model_error=service_error;model_stale=offer_stale||kill;offer_stale=0;requests++;
        end
        clk=0;cycles++;
    endtask
    task automatic reset_domain;
        rst_n=0;clk=0;drain=0;redirect=0;consumer_ready=0;memory.req_ready=0;memory.resp_valid=0;memory.resp_error=0;memory.resp_rdata=0;memory.resp_id=0;
        model_live=0;model_stale=0;model_error=0;offer_stale=0;model_pc=0;model_delay=0;previous_held=0;previous_token_stalled=0;fault_barrier=0;restart_check=0;service_latency=1;service_error=0;resume_pc=RESET_PC;
        #1;clk=1;#1;clk=0;rst_n=1;
    endtask
    initial begin
        int before_reuse,before_tokens;
        if($value$plusargs("transport_trace_dir=%s",trace_dir))begin
            trace_fd=$fopen($sformatf("%s/transport_%08h.csv",trace_dir,RESET_PC),"w");
            $fwrite(trace_fd,"edge,req_fire,req_pc,resp_fire,owner_pc,p_fire,p_pc,response_error,stale,fault,local_fault,redirect,drain,kill\n");
        end
        reset_domain();
        // Run at an aligned restart even when cold RESET_PC is unaligned.
        tick(1,1,0,1,32'h80000400);before_reuse=same_edge_reuse;before_tokens=tokens;
        repeat(128)tick(1,1,0,0,0);
        if(REQUIRE_II1)assert(same_edge_reuse-before_reuse>=120&&tokens-before_tokens>=120) else $fatal(1,"L1/II1 supply failed: tokens=%0d reuse=%0d",tokens-before_tokens,same_edge_reuse-before_reuse);
        // Stall successor offer, then several redirects while it is irrevocable.
        reset_domain();tick(0,1,0,1,32'h80001000);tick(0,1,0,0,0);tick(0,1,0,1,32'h80002000);tick(0,1,0,1,32'h80003000);
        service_latency=5;service_error=1;tick(1,1,0,0,0);service_error=0;repeat(20)tick(1,1,0,0,0);
        // Redirect collision consumes a stale error and retains latest target.
        reset_domain();tick(1,1,0,1,32'h80004000);service_error=1;tick(1,1,0,0,0);service_error=0;tick(1,1,0,1,32'h80005000);repeat(8)tick(1,1,0,0,0);
        // Fresh error may stall, but fault barrier must still permit its token.
        reset_domain();tick(1,1,0,1,32'h80006000);service_error=1;tick(1,0,0,0,0);service_error=0;repeat(6)tick(1,0,0,0,0);tick(1,1,0,0,0);repeat(4)tick(1,1,0,0,0);tick(1,1,0,1,32'h80007000);repeat(8)tick(1,1,0,0,0);
        // Exactly one locally assembled fault token, and no unaligned request.
        reset_domain();tick(1,0,0,1,32'h80008002);repeat(6)tick(1,0,0,0,0);tick(1,1,0,0,0);repeat(4)tick(1,1,0,0,0);tick(1,1,0,1,32'h80009000);repeat(8)tick(1,1,0,0,0);
        // Quiesce drains response even when token sink is blocked, then resumes.
        reset_domain();tick(0,0,0,1,32'h8000a000);tick(0,0,0,0,0);tick(0,0,1,0,0);service_latency=4;tick(1,0,1,0,0);repeat(12)tick(1,0,1,0,0);service_latency=1;repeat(12)tick(1,1,0,0,0);
        for(int n=0;n<6000;n++)begin
            logic[31:0]choice,target;
            choice=random_word();target=32'h80000000|(random_word()&32'h0000fffc);if(choice[23:19]==0)target[1:0]=2;
            service_latency=1+int'(random_word()%7);service_error=choice[18:15]==0;
            tick(choice[0]||choice[1],choice[2]||choice[3],choice[8:4]<4,choice[13:9]==0,target);
        end
        repeat(16)tick(1,0,1,0,0);
        assert(requests>0&&tokens>0&&stalled_requests>0&&stalled_tokens>0&&held_redirects>0&&pending_redirects>0&&response_redirects>0&&stale_faults>0&&drain_responses>0&&local_faults>0&&fresh_faults>0) else $fatal(1,"Missing transport coverage reset=%h req=%0d token=%0d held=%0d pending=%0d response=%0d stale_error=%0d drain=%0d local=%0d fresh=%0d",RESET_PC,requests,tokens,held_redirects,pending_redirects,response_redirects,stale_faults,drain_responses,local_faults,fresh_faults);
        $display("PASS frontend transport reset=%h policy=%0d early_jal=%0d ii1_required=%0d cycles=%0d requests=%0d tokens=%0d reuse=%0d held_redirects=%0d pending_redirects=%0d response_redirects=%0d stale_errors=%0d drain=%0d local_faults=%0d fresh_faults=%0d stalled_tokens=%0d",RESET_PC,COND_POLICY,EARLY_JAL_EN,REQUIRE_II1,cycles,requests,tokens,same_edge_reuse,held_redirects,pending_redirects,response_redirects,stale_faults,drain_responses,local_faults,fresh_faults,stalled_tokens);
        if(trace_fd!=0)$fclose(trace_fd);
        done=1;
    end
endmodule
module frontend_transport_tb #(
    parameter int unsigned COND_POLICY=0,
    parameter bit EARLY_JAL_EN=0,REQUIRE_II1=1
);
    logic aligned_done,misaligned_done;
    frontend_transport_engine #(.COND_POLICY(COND_POLICY),.EARLY_JAL_EN(EARLY_JAL_EN),.REQUIRE_II1(REQUIRE_II1)) aligned(.done(aligned_done));
    frontend_transport_engine #(.RESET_PC(32'h80000002),.SEED(32'ha9172ce5),.COND_POLICY(COND_POLICY),.EARLY_JAL_EN(EARLY_JAL_EN),.REQUIRE_II1(REQUIRE_II1)) misaligned(.done(misaligned_done));
    initial begin wait(aligned_done&&misaligned_done);$display("PASS frontend transport both reset profiles");$finish;end
endmodule
