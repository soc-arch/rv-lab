// =============================================================================
// HY-RV | static_prediction_tb
// Description: Directed static prediction and integrated successor recovery checks.
//
// Purpose: Computer architecture and RTL design education and lab exercises.
// Maintained by: DSAL (Digital System Architecture Lab), Hanyang University
// Website: https://dsa.hanyang.ac.kr
// Supervisor: Prof. Ji-Hoon Kim (jhoonkim@hanyang.ac.kr)
//
// AI tools such as Codex or Claude may have assisted in creating or modifying
// this file. See the applicable manifests and verification records for
// file-specific provenance, revision history, and validation evidence.
// Preserve existing license, copyright, and original author notices.
// =============================================================================

// Static policy arithmetic/encoding and integrated F->P successor recovery.
// Unit vectors are design obligations; core events below are measured RTL.
module static_prediction_tb #(
    parameter int unsigned COND_POLICY=0,
    parameter bit EARLY_JAL_EN=0
);
    import rv_bp_pkg::*;
    logic clk=0,rst_n=0;
    logic unit_valid=0;
    logic [31:0] unit_pc=0,unit_insn=0;
    bp_predecode_t unit_predecode;
    bp_lookup_t unit_lookup;
    bp_prediction_t unit_prediction;
    rv_branch_predecode predecode(.valid_i(unit_valid),.pc_i(unit_pc),.insn_i(unit_insn),.predecode_o(unit_predecode));
    rv_branch_predictor #(.BP_PROFILE(COND_POLICY),.COND_POLICY(COND_POLICY),.EARLY_JAL_EN(EARLY_JAL_EN),.STATIC_POLICY_EN(1)) predictor(
        .clk,.rst_n,.lookup_valid_i(unit_valid),.lookup_pc_i(unit_pc),.lookup_record_o(unit_lookup),
        .refine_valid_i(unit_valid),.refine_pc_i(unit_pc),.predecode_i(unit_predecode),.saved_lookup_i('0),.effective_o(unit_prediction),
        .update_valid_i(1'b0),.update_i('0),.invalidate_frontend_state_i(1'b0));

    mem_if imem(),dmem();
    logic drain_done,commit_valid,commit_rd_we;
    logic [31:0] commit_pc,commit_rd_data;
    logic [4:0] commit_rd;
    logic [15:0] events;
    rv_trace_pkg::cpu_trace_t trace;
    rv_core_simple #(.COND_POLICY(COND_POLICY),.BP_PROFILE(COND_POLICY),.EARLY_JAL_EN(EARLY_JAL_EN),.STATIC_POLICY_EN(1),.SUCCESSOR_CHECK_EN(1)) core(
        .clk,.rst_n,.imem_if(imem),.dmem_if(dmem),.drain_req_i(1'b0),.drain_done_o(drain_done),
        .irq_software_i(1'b0),.irq_timer_i(1'b0),.irq_external_i(1'b0),
        .commit_valid,.commit_pc,.commit_rd,.commit_rd_data,.commit_rd_we,.events_o(events),.trace_o(trace));

    localparam logic [31:0] BASE=32'h8000_0000;
    logic [31:0] program_words[0:127];
    bit i_live=0;
    logic [31:0] i_pc;
    int unit_checks=0,core_checks=0,tokens=0,corrections=0,correct_taken=0,traps=0;
    int cycles=0;

    function automatic logic [31:0] branch(input int off,input int f3);
        logic [12:0] imm;
        imm=13'(off);
        return {imm[12],imm[10:5],5'd2,5'd1,3'(f3),imm[4:1],imm[11],7'h63};
    endfunction
    function automatic logic [31:0] jal(input int off,input int rd);
        logic [20:0] imm;
        imm=21'(off);
        return {imm[20],imm[10:1],imm[11],imm[19:12],5'(rd),7'h6f};
    endfunction
    function automatic logic [31:0] addi(input int rd,input int rs,input int imm);
        return {12'(imm),5'(rs),3'b000,5'(rd),7'h13};
    endfunction
    function automatic bp_prediction_t expected_prediction(input logic[31:0] pc,input int off,input int kind,input bit legal);
        bp_prediction_t result;
        logic [31:0] target;
        bit choose;
        result='0;result.next_pc=pc+32'd4;
        target=pc+32'(off);
        choose=legal&&((kind==1&&COND_POLICY==1&&off<0)||(kind==2&&EARLY_JAL_EN));
        if(choose) begin
            if(target[1:0]==0) begin
                result.taken=1;result.next_pc=target;result.source=kind==2?BP_EARLY_JAL:BP_BTFNT;result.refine_flags[0]=1;
            end else result.refine_flags[3]=1;
        end
        return result;
    endfunction

    task automatic check_unit(input logic[31:0] pc,input logic[31:0] word,input int off,input int kind,input bit legal);
        bp_prediction_t expected;
        unit_pc=pc;unit_insn=word;unit_valid=1;#1;
        expected=expected_prediction(pc,off,kind,legal);
        assert(unit_lookup=='0) else $fatal(1,"Static predictor unexpectedly has lookup state");
        assert(unit_predecode.kind==(legal?2'(kind):CFI_NONE)) else $fatal(1,"Predecode whitelist pc=%h word=%h kind=%h",pc,word,unit_predecode.kind);
        assert(unit_prediction==expected) else $fatal(1,"Policy pc=%h off=%0d kind=%0d expected=%h actual=%h policy=%0d jal=%0d",pc,off,kind,expected,unit_prediction,COND_POLICY,EARLY_JAL_EN);
        if(legal&&(kind==1||kind==2)) begin
            assert(unit_predecode.direct_target_valid&&unit_predecode.direct_target==pc+32'(off)) else $fatal(1,"Wrong direct target/wrap");
            if(kind==1)assert(unit_predecode.offset_negative==(off<0)) else $fatal(1,"Wrong signed immediate");
        end
        unit_checks++;
        unit_valid=0;#1;
        assert(unit_predecode.kind==CFI_NONE&&!unit_prediction.taken&&unit_prediction.next_pc==pc+32'd4&&unit_prediction.source==0&&unit_prediction.refine_flags==0) else $fatal(1,"Invalid refinement predicted a control transfer");
        unit_checks++;
    endtask

    task automatic drive_memory;
        imem.resp_valid=i_live;imem.resp_id=0;imem.resp_error=0;
        imem.resp_rdata=i_live&&i_pc>=BASE&&i_pc<BASE+512?program_words[(i_pc-BASE)>>2]:32'h13;
        dmem.req_ready=1;dmem.resp_valid=0;dmem.resp_id=0;dmem.resp_error=0;dmem.resp_rdata=0;
        imem.req_ready=0;#1;
        imem.req_ready=!i_live||(imem.resp_valid&&imem.resp_ready);#1;
    endtask
    task automatic sample_edge;
        bit accepted,consumed;
        logic [31:0] address;
        accepted=imem.req_valid&&imem.req_ready;consumed=imem.resp_valid&&imem.resp_ready;address=imem.req_addr;
        clk=1;#1;
        if(consumed)i_live=0;
        if(accepted)begin assert(!i_live) else $fatal(1,"Memory overcommit");i_live=1;i_pc=address;end
        clk=0;cycles++;
    endtask
    task automatic reset_core;
        rst_n=0;clk=0;i_live=0;
        imem.req_ready=0;imem.resp_valid=0;imem.resp_id=0;imem.resp_error=0;imem.resp_rdata=0;
        dmem.req_ready=1;dmem.resp_valid=0;dmem.resp_id=0;dmem.resp_error=0;dmem.resp_rdata=0;
        #1;clk=1;#1;clk=0;rst_n=1;
    endtask

    task automatic measure_overlap;
        string trace_file;
        int fd,triple;
        triple=0;fd=0;
        if($value$plusargs("trace_file=%s",trace_file))begin
            fd=$fopen(trace_file,"w");
            $fwrite(fd,"edge,req_fire,req_pc,resp_fire,p_fire,p_pc,commit,commit_pc,redirect,trap,drain\n");
        end
        for(int n=0;n<128;n++)program_words[n]=32'h13;
        reset_core();
        for(int n=0;n<24;n++)begin
            drive_memory();
            if(imem.req_valid&&imem.req_ready&&trace.fetch_accepted&&commit_valid)begin
                assert(commit_pc+4==trace.fetch_pc&&trace.fetch_pc+4==imem.req_addr) else $fatal(1,"I/I+1/I+2 overlap ownership");
                triple++;
            end
            if(fd!=0)$fwrite(fd,"%0d,%0d,%08h,%0d,%0d,%08h,%0d,%08h,%0d,%0d,0\n",n,imem.req_valid&&imem.req_ready,imem.req_addr,imem.resp_valid&&imem.resp_ready,trace.fetch_accepted,trace.fetch_pc,commit_valid,commit_pc,trace.redirect_valid,trace.trap_valid);
            sample_edge();
        end
        if(fd!=0)$fclose(fd);
        assert(triple>=20) else $fatal(1,"P1 triple overlap failed count=%0d",triple);
        $display("PASS measured P1 triple overlap policy=%0d early_jal=%0d triple_edges=%0d sampled_edges=24",COND_POLICY,EARLY_JAL_EN,triple);
    endtask

    task automatic core_case(input logic[31:0] word,input int off,input int kind,input bit legal,input int a,input int b,input bit actual_taken,input bit target_fault,input int link_rd);
        bp_prediction_t expected;
        logic [31:0] tested_pc,target,actual_next;
        bit got_token,got_completion,got_next;
        int expected_commit;
        for(int n=0;n<128;n++)program_words[n]=32'h13;
        program_words[0]=addi(1,0,a);program_words[1]=addi(2,0,b);program_words[2]=word;
        tested_pc=BASE+8;target=tested_pc+32'(off);actual_next=actual_taken?target:tested_pc+4;
        expected=expected_prediction(tested_pc,off,kind,legal);
        got_token=0;got_completion=0;got_next=0;expected_commit=0;
        reset_core();
        for(int n=0;n<100;n++)begin
            drive_memory();
            if(trace.fetch_accepted&&trace.fetch_pc==tested_pc&&!got_token)begin
                assert(core.p_if.prediction==expected&&core.p_if.bp_meta=='0) else $fatal(1,"F->P static payload mismatch pc=%h expected=%h actual=%h",tested_pc,expected,core.p_if.prediction);
                got_token=1;tokens++;
                if(expected.taken)assert(imem.req_valid&&imem.req_addr==expected.next_pc) else $fatal(1,"Refined target not selected at token acceptance");
            end
            if(trace.trap_valid)begin
                assert(!legal||target_fault) else $fatal(1,"Unexpected core trap word=%h cause=%h",word,trace.trap_cause);
                assert(trace.trap_pc==tested_pc&&!commit_valid&&core.bp_update_valid==0) else $fatal(1,"Trap was imprecise or trained BP");
                assert(trace.trap_cause==(target_fault?0:2)) else $fatal(1,"Wrong trap cause");
                if(target_fault)assert(trace.trap_value==target) else $fatal(1,"Wrong taken misalignment mtval");
                got_completion=1;got_next=1;traps++;sample_edge();break;
            end
            if(commit_valid)begin
                if(!got_completion)begin
                    assert(commit_pc==BASE+32'(expected_commit*4)) else $fatal(1,"Retire order violated got=%h expected=%h",commit_pc,BASE+32'(expected_commit*4));
                    expected_commit++;
                    if(commit_pc==tested_pc)begin
                        assert(legal&&!target_fault) else $fatal(1,"Illegal/faulting instruction retired");
                        assert(trace.redirect_valid==(expected.next_pc!=actual_next)) else $fatal(1,"Correction compares successor incorrectly word=%h pred=%h actual=%h redirect=%b",word,expected.next_pc,actual_next,trace.redirect_valid);
                        assert(core.bp_update_valid&&core.bp_update.actual_next_pc==actual_next) else $fatal(1,"Ordinary completion/update absent or wrong");
                        if(trace.redirect_valid)begin assert(trace.redirect_pc==actual_next);corrections++;end
                        if(expected.taken&&actual_taken&&!trace.redirect_valid)correct_taken++;
                        if(kind==2)begin
                            assert(commit_rd_we==(link_rd!=0)&&commit_rd==5'(link_rd));
                            if(link_rd!=0)assert(commit_rd_data==tested_pc+4) else $fatal(1,"JAL link write changed");
                        end
                        got_completion=1;
                    end
                end else begin
                    assert(commit_pc==actual_next) else $fatal(1,"Wrong-path token retired after correction got=%h expected=%h",commit_pc,actual_next);
                    got_next=1;sample_edge();break;
                end
            end
            sample_edge();
        end
        assert(got_token&&got_completion&&got_next) else $fatal(1,"Incomplete integrated vector word=%h",word);
        core_checks++;
    endtask

    initial begin
        int b_offsets[9]='{-4096,-16,-4,-2,0,2,4,8,4094};
        int j_offsets[9]='{-1048576,-16,-4,-2,0,2,4,8,1048574};
        int f3s[6]='{0,1,4,5,6,7};
        logic[31:0] pcs[5]='{32'h80000000,32'h00000000,32'hfffffffc,32'h7ffffffc,32'h80000002};
        int links[3]='{0,1,5};
        measure_overlap();
        foreach(pcs[p])begin
            foreach(b_offsets[o])foreach(f3s[f])check_unit(pcs[p],branch(b_offsets[o],f3s[f]),b_offsets[o],1,1);
            foreach(j_offsets[o])foreach(links[r])check_unit(pcs[p],jal(j_offsets[o],links[r]),j_offsets[o],2,1);
            check_unit(pcs[p],branch(-4,2),-4,1,0);check_unit(pcs[p],branch(-4,3),-4,1,0);
            for(int f=0;f<8;f++)check_unit(pcs[p],{12'b0,5'd1,3'(f),5'd1,7'h67},0,3,f==0);
            check_unit(pcs[p],32'hffffffff,0,0,0);check_unit(pcs[p],32'h13,0,0,1);
        end
        // Every legal B comparison executes both directions, backward and forward.
        foreach(f3s[f])begin
            int a,b;bit t;
            a=f3s[f] inside {4,5}? -1:1;b=2;
            t=f3s[f] inside {1,4,6};
            core_case(branch(-4,f3s[f]),-4,1,1,a,b,t,0,0);
            core_case(branch(8,f3s[f]),8,1,1,a,b,t,0,0);
            core_case(branch(-4,f3s[f]),-4,1,1,b,f3s[f] inside {0,1}?b:a,!t,0,0);
        end
        core_case(branch(0,0),0,1,1,1,1,1,0,0);
        core_case(branch(4,1),4,1,1,1,1,0,0,0); // direction can differ while NPC agrees
        core_case(branch(-2,0),-2,1,1,1,2,0,0,0); // actual NT, encoded unaligned target is harmless
        core_case(branch(2,0),2,1,1,1,1,1,1,0); // only actual taken faults
        core_case(branch(-4,2),-4,1,0,1,1,0,0,0);
        core_case(branch(-4,3),-4,1,0,1,1,0,0,0);
        core_case({12'b0,5'd1,3'd1,5'd1,7'h67},0,3,0,1,1,0,0,0);
        core_case(32'hffffffff,0,0,0,1,1,0,0,0);
        foreach(links[r])begin
            core_case(jal(8,links[r]),8,2,1,1,2,1,0,links[r]);
            core_case(jal(-4,links[r]),-4,2,1,1,2,1,0,links[r]);
            core_case(jal(4,links[r]),4,2,1,1,2,1,0,links[r]);
        end
        core_case(jal(2,1),2,2,1,1,2,1,1,1);
        assert(unit_checks>800&&core_checks>=36&&tokens>=36&&traps>=5&&corrections>0);
        if(COND_POLICY==1||EARLY_JAL_EN)assert(correct_taken>0) else $fatal(1,"Enabled static policy was not exercised");
        $display("PASS static prediction policy=%0d early_jal=%0d unit_checks=%0d core_cases=%0d tokens=%0d corrections=%0d correct_taken=%0d traps=%0d cycles=%0d",COND_POLICY,EARLY_JAL_EN,unit_checks,core_checks,tokens,corrections,correct_taken,traps,cycles);
        $finish;
    end
endmodule
