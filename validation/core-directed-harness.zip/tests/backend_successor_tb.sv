// =============================================================================
// HY-RV | backend_successor_tb
// Description: Directed backend prediction validation, correction, and fault checks.
//
// Purpose: Computer architecture and RTL design education and lab exercises.
// Maintained by: DSAL (Digital System Architecture Lab), Hanyang University
// Website: https://dsa.hanyang.ac.kr
// Supervisor: Prof. Ji-Hoon Kim (jhoonkim@hanyang.ac.kr)
//
// AI tools such as Codex or Claude may have assisted in creating or modifying
// this file. See the applicable manifests and verification records for
// file-specific provenance, revision history, and validation evidence.
// Preserve existing license, copyright, and original author notices.
// =============================================================================

// Direct P-boundary tests. Prediction values are deliberately injected;
// these cases test carried effective-NPC validation independently of F policy.
module backend_successor_tb;
    logic clk=0, rst_n=0;
    logic irq_software=0, irq_timer=0, irq_external=0;
    insn_supply_if f_if();
    insn_supply_if p_if();
    mem_if dmem();
    logic commit_valid, commit_rd_we, idle, bp_valid, invalidate;
    logic [31:0] commit_pc, commit_data, resume_pc;
    logic [4:0] commit_rd;
    logic [15:0] events;
    logic [2:0] reason;
    rv_trace_pkg::cpu_trace_t trace;
    rv_bp_pkg::bp_update_t update_record;
    int checks=0;
    localparam logic [31:0] BASE=32'h8000_0000;

    rv_insn_link u_link (.rst_n,.flush_i(p_if.flush),.f_if,.p_if);
    rv_backend #(.RESET_PC(BASE),.SUCCESSOR_CHECK_EN(1)) u_backend (
        .clk,.rst_n,.insn_if(p_if),.dmem_if(dmem),.idle_o(idle),
        .irq_software_i(irq_software),.irq_timer_i(irq_timer),.irq_external_i(irq_external),
        .events_o(events),.commit_valid,.commit_pc,.commit_rd,
        .commit_rd_data(commit_data),.commit_rd_we,.trace_o(trace),
        .bp_update_valid_o(bp_valid),.bp_update_o(update_record),
        .bp_invalidate_o(invalidate),.resume_pc_o(resume_pc),.redirect_reason_o(reason)
    );

    function automatic logic [31:0] b_word(input int offset, input logic [2:0] f3,
                                           input logic [4:0] rs1=0, rs2=0);
        logic [12:0] v;
        v=13'(offset);
        return {v[12],v[10:5],rs2,rs1,f3,v[4:1],v[11],7'h63};
    endfunction
    function automatic logic [31:0] j_word(input int offset, input logic [4:0] rd=0);
        logic [20:0] v;
        v=21'(offset);
        return {v[20],v[10:1],v[11],v[19:12],rd,7'h6f};
    endfunction
    function automatic logic [31:0] i_word(input int imm, input logic [4:0] rs1,
                                           input logic [2:0] f3, input logic [4:0] rd,
                                           input logic [6:0] op=7'h13);
        return {12'(imm),rs1,f3,rd,op};
    endfunction
    function automatic logic [31:0] csr_imm(input logic [11:0] csr,
                                            input logic [4:0] value);
        return {csr,value,3'b101,5'd0,7'h73};
    endfunction

    task automatic check(input logic condition, input string name);
        if (!condition) $fatal(1,"backend directed check failed: %s",name);
        checks++;
    endtask
    task automatic tick;
        #5; clk=1; #5; clk=0; #1;
    endtask
    task automatic reset_case;
        rst_n=0;
        f_if.valid=0; f_if.pc=BASE; f_if.insn=32'h13;
        f_if.fault=0; f_if.fault_misaligned=0;
        f_if.predicted_taken=0; f_if.predicted_target=0;
        f_if.predicted_ghr_snapshot=0;
        f_if.prediction='0; f_if.bp_meta='0;
        irq_software=0; irq_timer=0; irq_external=0;
        dmem.req_ready=1; dmem.resp_valid=0; dmem.resp_id=0;
        dmem.resp_rdata=0; dmem.resp_error=0;
        tick(); tick(); rst_n=1; #1;
        check(idle && resume_pc==BASE,"reset architectural resume PC");
    endtask
    task automatic admit(input logic [31:0] word, pc, npc,
                          input logic predicted_taken=0, fetch_fault=0, fetch_misaligned=0);
        f_if.valid=1; f_if.pc=pc; f_if.insn=word;
        f_if.fault=fetch_fault; f_if.fault_misaligned=fetch_misaligned;
        f_if.prediction='0;
        f_if.prediction.taken=predicted_taken;
        f_if.prediction.next_pc=npc;
        f_if.prediction.source=rv_bp_pkg::BP_BTFNT;
        f_if.prediction.refine_flags=4'ha;
        f_if.bp_meta=48'h1234_5678_abcd;
        #1;
        check(f_if.ready && p_if.valid,"token accepted at P boundary");
        tick(); f_if.valid=0; #1;
        check(trace.execute_pc==pc && trace.execute_insn==word,"IR owner captured");
    endtask
    task automatic ordinary(input logic [31:0] npc, input logic correction,
                             input logic [1:0] kind=0, input logic taken=0,
                             input logic [31:0] target=0);
        #1;
        check(commit_valid && bp_valid && !invalidate,"ordinary retirement and feedback");
        check(update_record.actual_next_pc==npc,"actual successor");
        check(update_record.actual_kind==kind && update_record.actual_taken==taken,
              "actual kind and direction");
        check(update_record.resolved_target_valid==(kind!=0) &&
              update_record.resolved_target==target,"resolved encoded target");
        check(update_record.prediction.source==1 &&
              update_record.prediction.refine_flags==4'ha &&
              update_record.bp_meta==48'h1234_5678_abcd,"complete carried record preserved");
        check(p_if.redirect_valid==correction && reason==(correction ? 5 : 0),"NPC correction only");
        if (correction) check(p_if.redirect_pc==npc,"correction target");
        tick();
        check(idle && resume_pc==npc,"ordinary architectural resume");
    endtask
    task automatic control(input logic [2:0] expected_reason,
                            input logic [31:0] expected_target,
                            input logic fence_i=0);
        #1;
        check(p_if.redirect_valid && p_if.redirect_pc==expected_target &&
              reason==expected_reason,"typed control redirect priority");
        check(!bp_valid && invalidate==fence_i,"control excludes ordinary feedback");
        check(commit_valid==fence_i && !commit_rd_we && !dmem.req_valid,
              "control architectural side effects");
        check(!(p_if.valid && p_if.ready),"redirect kills younger P admission");
        tick();
        check(idle && resume_pc==expected_target,"control architectural resume");
    endtask
    task automatic setup_irq;
        admit(csr_imm(12'h304,8),BASE,BASE+4); ordinary(BASE+4,0);
        admit(csr_imm(12'h300,8),BASE+4,BASE+8); ordinary(BASE+8,0);
        irq_software=1; #1;
    endtask

    initial begin
        reset_case();
        admit(i_word(7,0,0,1),BASE,BASE+32,1);
        check(commit_rd_we && commit_data==7,"non-CFI result survives correction");
        // A younger CSR token offered in the correction cycle is killed.
        f_if.valid=1; f_if.pc=BASE+32; f_if.insn=csr_imm(12'h340,31); #1;
        check(!f_if.ready && !p_if.valid,"wrong-path CSR admission suppressed");
        ordinary(BASE+4,1);
        f_if.valid=0;
        admit({12'h340,5'd0,3'b010,5'd2,7'h73},BASE+4,BASE+8);
        check(commit_data==0,"wrong-path CSR has no architectural write");
        ordinary(BASE+8,0);

        // On one rising edge, I commits and I+1 replaces its IR. RF reads
        // observe I's completed write during I+1 execution without forwarding.
        reset_case(); admit(i_word(7,0,0,1),BASE,BASE+4);
        f_if.valid=1; f_if.pc=BASE+4; f_if.insn=i_word(1,1,0,2);
        f_if.prediction.next_pc=BASE+8; #1;
        check(commit_valid && p_if.valid && p_if.ready,"commit plus IR replacement edge");
        tick(); f_if.valid=0; #1;
        check(trace.rs1_value==7 && commit_rd==2 && commit_data==8,
              "dependent instruction reads completed RF write");
        ordinary(BASE+8,0);

        reset_case();
        admit(b_word(-8,1),BASE+8,BASE,1); // BNE x0,x0: predicted T -> actual NT.
        ordinary(BASE+12,1,1,0,BASE);
        reset_case();
        admit(b_word(8,0),BASE,BASE+4); // BEQ x0,x0: predicted NT -> actual T.
        ordinary(BASE+8,1,1,1,BASE+8);
        reset_case();
        admit(b_word(-8,0),BASE+8,BASE,1);
        ordinary(BASE,0,1,1,BASE);
        reset_case(); admit(j_word(8,1),BASE,BASE+12,1); // Correct T, wrong target.
        ordinary(BASE+8,1,2,1,BASE+8);
        reset_case();
        admit(b_word(4,1),BASE,BASE+4,1); // Direction wrong, successor identical.
        ordinary(BASE+4,0,1,0,BASE+4);
        reset_case();
        admit(b_word(2,1),BASE,BASE+4); // Untaken unaligned target is legal.
        ordinary(BASE+4,0,1,0,BASE+2);
        reset_case();
        admit(b_word(2,0),BASE,BASE+4);
        check(trace.trap_valid && trace.trap_cause==0 && trace.trap_value==BASE+2,
              "actual taken unaligned branch traps");
        control(1,0);

        // All six legal B funct3 values compare through P, independently of F.
        for (int f3=0; f3<8; f3++) begin
            if (f3 inside {0,1,4,5,6,7}) begin
                bit t;
                t=f3 inside {0,5,7};
                reset_case();
                admit(b_word(8,3'(f3)),BASE,t ? BASE+8 : BASE+4,t);
                ordinary(t ? BASE+8 : BASE+4,0,1,t,BASE+8);
            end
        end
        for (int f3=2; f3<4; f3++) begin
            reset_case(); admit(b_word(-8,3'(f3)),BASE,BASE-8,1);
            check(trace.trap_cause==2,"reserved B encoding illegal"); control(1,0);
        end
        reset_case(); admit(i_word(0,0,1,1,7'h67),BASE,BASE+32,1);
        check(trace.trap_cause==2,"reserved JALR encoding illegal"); control(1,0);
        reset_case(); admit(i_word(3,0,1,1,7'h67),BASE,BASE+32,1);
        check(trace.trap_cause==2 && trace.trap_value==i_word(3,0,1,1,7'h67),
              "illegal JALR does not create an architectural target fault"); control(1,0);

        for (int rd=0; rd<6; rd++) begin
            if (rd inside {0,1,5}) begin
                reset_case(); admit(j_word(8,5'(rd)),BASE,BASE+8,1);
                check(commit_rd_we==(rd!=0) && commit_data==BASE+4,"JAL link x0/x1/x5");
                ordinary(BASE+8,0,2,1,BASE+8);
            end
        end
        reset_case(); admit(j_word(2,1),BASE,BASE+4);
        check(trace.trap_value==BASE+2,"actual JAL unaligned target"); control(1,0);
        reset_case(); admit(i_word(1,0,0,1,7'h67),BASE,0,1);
        ordinary(0,0,3,1,0); // JALR clears bit0.
        reset_case(); admit(i_word(3,0,0,1,7'h67),BASE,BASE+4);
        check(trace.trap_value==2,"JALR bit1 target fault"); control(1,0);

        reset_case(); admit(b_word(-4,0),0,32'hffff_fffc,1);
        ordinary(32'hffff_fffc,0,1,1,32'hffff_fffc);
        reset_case(); admit(i_word(0,0,0,0),32'hffff_fffc,0);
        ordinary(0,0);
        reset_case(); admit(32'h0000100f,BASE,BASE+32,1);
        control(4,BASE+4,1);
        reset_case(); admit(32'h30200073,BASE,BASE+32,1);
        control(3,0);
        reset_case(); admit(csr_imm(12'h341,20),BASE,BASE+4); ordinary(BASE+4,0);
        admit(32'h30200073,BASE+4,BASE+32,1); control(3,20);
        reset_case(); admit(32'h00000073,BASE,BASE+32,1);
        check(trace.trap_cause==11,"ECALL control cause"); control(1,0);
        reset_case(); admit(csr_imm(12'h305,16),BASE,BASE+4); ordinary(BASE+4,0);
        admit(32'h00000073,BASE+4,BASE+32,1); control(1,16);
        reset_case(); admit(32'h00100073,BASE,BASE+32,1);
        check(trace.trap_cause==3,"EBREAK control cause"); control(1,0);
        reset_case(); admit(32'h00000013,BASE,BASE+32,1,1);
        check(trace.trap_cause==1,"instruction memory error token"); control(1,0);
        reset_case(); admit(j_word(2,1),BASE,BASE+32,1,1);
        check(trace.trap_cause==1 && trace.trap_value==BASE,
              "fetch error outranks decoded target misalignment"); control(1,0);
        reset_case(); admit(32'h00000013,BASE+2,BASE+6,0,1,1);
        check(trace.trap_cause==0,"local fetch alignment token"); control(1,0);

        // IRQ outranks ordinary correction and mret; synchronous trap outranks IRQ.
        reset_case(); setup_irq();
        admit(i_word(5,0,0,1),BASE+8,BASE+32,1);
        check(trace.trap_cause==32'h8000_0003,"IRQ ordinary preemption"); control(2,0);
        reset_case(); setup_irq(); admit(32'h30200073,BASE+8,BASE+32,1); control(2,0);
        reset_case(); setup_irq(); admit(32'h0000100f,BASE+8,BASE+32,1); control(2,0);
        reset_case(); setup_irq(); admit(32'hffff_ffff,BASE+8,BASE+32,1);
        check(trace.trap_cause==2,"exception priority over IRQ"); control(1,0);
        reset_case(); setup_irq(); admit(i_word(2,0,2,1,7'h03),BASE+8,BASE+32,1);
        check(trace.trap_cause==4,"load alignment exception priority over IRQ"); control(1,0);

        // A preempted DIV must not leave its FU busy. Return to the preempted
        // PC and perform a different division with a distinguishable result.
        reset_case(); setup_irq(); admit(32'h020040b3,BASE+8,BASE+32,1);
        check(trace.trap_cause==32'h8000_0003,"IRQ preempts DIV dispatch"); control(2,0);
        irq_software=0;
        admit(32'h30200073,0,BASE+64,1); control(3,BASE+8);
        admit(i_word(21,0,0,1),BASE+8,BASE+12); ordinary(BASE+12,0);
        admit(i_word(3,0,0,2),BASE+12,BASE+16); ordinary(BASE+16,0);
        admit(32'h0220c1b3,BASE+16,BASE+20); tick();
        repeat(32) begin check(!bp_valid && !commit_valid,"DIV after IRQ waits normally"); tick(); end
        check(commit_rd_we && commit_rd==3 && commit_data==7,
              "canceled DIV does not contaminate DIV after mret"); ordinary(BASE+20,0);

        // Blocking LSU preserves metadata and cannot be preempted after first offer.
        reset_case(); admit(i_word(0,0,2,1,7'h03),BASE,BASE+4);
        dmem.req_ready=0; #1;
        check(dmem.req_valid && !commit_valid && !bp_valid,"load held request");
        repeat(4) begin tick(); check(dmem.req_valid && !bp_valid,"load remains held"); end
        dmem.req_ready=1; tick();
        check(dmem.resp_ready && !bp_valid,"load response owner wait");
        repeat(3) tick();
        dmem.resp_valid=1; dmem.resp_rdata=32'h12345678; tick(); dmem.resp_valid=0;
        check(commit_rd_we && commit_data==32'h12345678,"load delayed result");
        ordinary(BASE+4,0);
        reset_case(); setup_irq(); irq_software=0;
        admit(i_word(0,0,2,1,7'h03),BASE+8,BASE+12);
        dmem.req_ready=0; tick(); irq_software=1; #1;
        check(dmem.req_valid && !trace.trap_valid,"IRQ cannot withdraw a stalled request");
        repeat(3) begin tick(); check(dmem.req_valid && !bp_valid,"held request survives IRQ"); end
        dmem.req_ready=1; tick();
        check(dmem.resp_ready && !trace.trap_valid,"accepted load owns IRQ-safe response");
        dmem.resp_valid=1; dmem.resp_rdata=42; tick(); dmem.resp_valid=0;
        check(commit_data==42 && !trace.trap_valid,"load completes normally with pending IRQ");
        ordinary(BASE+12,0);
        reset_case(); admit(i_word(0,0,2,1,7'h03),BASE,BASE+32,1);
        tick(); dmem.resp_valid=1; dmem.resp_error=1; #1;
        check(trace.trap_cause==5,"load response error priority"); control(1,0);

        // MUL and DIV keep the same carried prediction until their completion.
        reset_case(); admit(32'h020000b3,BASE,BASE+32,1);
        check(!commit_valid && !bp_valid,"MUL dispatch has no completion"); tick();
        ordinary(BASE+4,1);
        reset_case(); admit(32'h020040b3,BASE,BASE+32,1);
        check(!commit_valid && !bp_valid,"DIV dispatch has no completion"); tick();
        repeat(32) begin check(!bp_valid && !commit_valid,"DIV wait no feedback"); tick(); end
        check(commit_data==32'hffff_ffff,"DIV zero divisor result"); ordinary(BASE+4,1);

        $display("BACKEND_SUCCESSOR_PASS checks=%0d",checks);
        $finish;
    end
endmodule
